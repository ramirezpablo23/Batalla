
let currentUser = sessionStorage.getItem("currentUser");
const allUsers = JSON.parse(localStorage.getItem("users") || "{}");

function loadUserPanel() {
  const user = allUsers[currentUser];
  document.getElementById("gold").textContent = user.gold || 0;
  document.getElementById("gems").textContent = user.gems || 0;
  let barColor = "green";
  if (user.hp < user.maxHp * 0.5) barColor = "yellow";
  if (user.hp < user.maxHp * 0.2) barColor = "red";
  const bar = document.getElementById("healthBar");
  bar.style.width = (user.hp / user.maxHp) * 100 + "%";
  bar.className = "healthBar " + barColor;
}

function loadCityUsers() {
  const container = document.getElementById("cityArea");
  for (let username in allUsers) {
    if (username === currentUser) continue;
    const div = document.createElement("div");
    div.className = "userCard";
    div.innerHTML = \`
      <img src="images/hero.png" alt="user" />
      <p>\${username}</p>
      <button onclick="alert('Desafiaste a \${username}')">⚔️ Desafiar</button>
    \`;
    container.appendChild(div);
  }
}

loadUserPanel();
loadCityUsers();
