
# 🕸️ Spidey vs Villains RPG

**Spidey vs Villains** es un juego RPG por turnos en el navegador, donde podrás combatir, subir de nivel, ganar oro y desbloquear personajes únicos.

## 🚀 Características
- Registro y login local
- Panel fijo con información del personaje
- Vista principal con ciudad e iconos de otros jugadores
- Sistema de combate básico
- Desafíos entre usuarios registrados en el navegador

## 📁 Estructura del proyecto
```
Spidey_vs_Villains_RPG/
├── index.html
├── /css/
│   └── style.css
├── /js/
│   └── main.js
├── /images/
│   ├── hero.png
│   └── city_bg.jpg
```

## 🔧 Cómo usarlo
1. Descargar o clonar este repositorio.
2. Asegurate de tener todos los archivos y carpetas en la raíz.
3. Abrí `index.html` en tu navegador, o servilo con Live Server para mejor compatibilidad.

## 🌍 Deploy en GitHub Pages
1. Subí todos los archivos a tu repositorio (sin carpetas comprimidas).
2. Activá GitHub Pages desde la configuración.
3. Accedé al juego desde `https://<tu-usuario>.github.io/<repo>/`

---

🎮 Hecho con 💻 por ramirezpablo23
